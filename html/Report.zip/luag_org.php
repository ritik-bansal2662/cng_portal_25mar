<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="w3.css">
    <title>Reconciliation Data at Organization Level</title>
    <style>
        container {
            margin: 50px 50px;
        }

        thead {
            color: white;

        }

        tbody {
            color: black;

        }

        tfoot {
            color: red;
        }

        table,
        th,
        td {
            border: 1px solid white;
        }

        .ddtf-processed th.option-item>select {
            display: none;
        }

        .ddtf-processed th.option-item>div {
            display: block !important;
        }
    </style>
</head>

<body>
    <div class="w3-container ">
        <div class="w3-responsive">
            <h2 align="center">Reconciliation Data at Organization Level</h2>
            <br>
            <table id="mytable2" class="w3-table-all w3-small">
                <thead ">
                <tr>
                <th bgcolor=" #02603E" class="header" scope="col"><strong>Date</strong></th>
                   <th bgcolor="#02603E" class="header" scope="col"><strong> LCV Number </strong></th>
                    <th bgcolor="#02603E" class="header" scope="col"><strong> Mother Gas Station </strong></th>
                    <th bgcolor="#02603E" class="header" scope="col"><strong> Daughter Booster Station </strong></th> 
                    <th bgcolor="#02603E" class="header option-item" scope="col"><strong> Amount of Gas filled at MGS (Kg)</strong></th>
                    <th bgcolor="#02603E" class="header option-item" scope="col"><strong> Amount of Gas delivered at DBS (Kg) </strong></th>
                    <th bgcolor="#02603E" class="header option-item" scope="col"><strong> Gas Loss during Transportation (Kg) </strong></th>

                    </tr>

                </thead>
                <tbody style="background-color: #E9C006; ">
                    <?php
                    $db = new PDO("mysql:host=localhost;dbname=cng_luag", "root", "");

                    $stmt = $db->prepare("SELECT *, 
                    sum(after_filling_at_mgs_mfm_value_read-before_filing_at_mgs_mass_cng) as total_gas_mgs_mfm, 
                    sum(after_filling_at_mgs_mass_cng-before_filing_at_mgs_mass_cng) as total_gas_mgs, 
                    sum(before_empty_at_db_mass_cng-after_empty_at_dbs_mass_cng) as total_gas_dbs,
                    sum(after_filling_at_mgs_mfm_value_read-before_empty_at_db_mass_cng) as total_gas_dbs_mfm , 
                    sum(after_filling_at_mgs_mfm_value_read - before_filing_at_mgs_mass_cng - 
                    (before_empty_at_db_mass_cng - after_empty_at_dbs_mass_cng)) gas_loss 
					,
					
					
                   sum(after_filling_at_mgs_mfm_value_read + before_filing_at_mgs_mass_cng - 
                    before_empty_at_db_mass_cng ) mfm_gas_loss 
                    from luag_transaction_master_dbs_station 
                    group by date_reading ORDER BY sl_no desc;");
                    $stmt->execute();
                    while ($row = $stmt->fetch()) {
                    ?>
                        <tr>
                            <td bgcolor="#E9C006">
                                <?php echo $row["date_reading"]; ?>
                            </td>
							 <td bgcolor="#E9C006">
                                <?php echo $row["lcv_id"]; ?>
                            </td>
							 <td bgcolor="#E9C006">
                                <?php echo $row["station_id"]; ?>
                            </td>
                           
                            <td bgcolor="#E9C006">
                                <?php echo $row["dbs_station_id"]; ?>
                            </td>

                            <td bgcolor="#E9C006">

                                <?php
                                if ($row["after_filling_at_mgs_mfm_value_read"] == 1) {
                                    echo round($row["total_gas_mgs"], 2);
                                } else {

                                    echo round($row["total_gas_mgs_mfm"], 2);
                                } ?>

                            </td>

                            <td bgcolor="#E9C006">
                                <?php

                                echo round($row["total_gas_dbs"], 2);

                                ?>
                            </td>
                            <td bgcolor="#E9C006">
                                <?php
								if($row["date_reading"]>='2022-02-15'){
									 echo round($row["mfm_gas_loss"], 2);
								}else{
                                if ($row["after_filling_at_mgs_mfm_value_read"] == 1) {
                                    echo round($row["total_gas_mgs"] - $row["total_gas_dbs"], 2);
                                } else {
                                    echo round($row["gas_loss"], 2);
                                }} ?>
                                <?php  ?>
                            </td>

                        </tr>
                    <?php
                        $decimalHours = 0;
                    }
                    ?>
                </tbody>
            </table>
            </br>

            <table id="mytable3" class="w3-table-all w3-small">
                <thead ">
                <tr>
                    <th bgcolor=" #02603E" class="header" scope="col"><strong>Date</strong></th>
                    <th bgcolor="#02603E" class="header" scope="col"><strong> LCV Number </strong></th>
                    
                    <th bgcolor="#02603E" class="header" scope="col"><strong> Daughter Booster Station </strong></th>
                    <th bgcolor="#02603E" class="header option-item" scope="col"><strong>Amount of Gas received at DBS (Kg)</strong></th>
					 <th bgcolor=" #02603E" class="header option-item" scope="col"><strong>Total Mass of Gas in Stationary Cascade (Kg)</strong></th>
                    <th bgcolor="#02603E" class="header option-item" scope="col"><strong> Amount of Gas sold at DBS through Dispenser (Kg) </strong></th>
                  

                    </tr>

                </thead>
                <tbody style="background-color: #E9C006; ">
                    <?php
                    try {
                        $db = new PDO("mysql:host=localhost;dbname=cng_luag", "root", "");
                        class Customers
                        {
                            private $servername = "localhost";
                            private $username   = "root";
                            private $password   = "";
                            private $dbname     = "cng_luag";
                            public  $con;

                            // Database Connection 
                            public function __construct()
                            {
                                try {
                                    $this->con = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
                                } catch (Exception $e) {
                                    echo $e->getMessage();
                                }
                            }

                            public function updateData()
                            {
                                $query = "Insert ignore  into luag_dispenser_reading 
                            (reading_timestamp,date_reading,dbs_station_id,cascade_mass,dispenser_id,dispenser_read,diff_dispenser_reading)
                            SELECT create_date,date(create_date),station_id,`mass_of_gas`,dispenser_id,dispenser_read, 
                            ((dispenser_read) - LAG(dispenser_read) OVER (PARTITION BY dispenser_id ORDER BY sl_no ))
                             dispenser_diff FROM `luag_transaction_dbs_dispenser_cascade`      
                            GROUP by dispenser_id,date_reading";
                                $sql = $this->con->query($query);
                                if ($sql == true) {
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        }
                        $customerObj = new Customers();
                        $customers = $customerObj->updateData();

                        // $stmt = $db->prepare("select lcv_id,t1.station_id,t1.dbs_station_id,t1.date_reading,create_date, total_gas_mgs_mfm,
                        // total_gas_mgs_calc,total_gas_dbs_calc,cascade_mass,total_sale
                        //  from (SELECT lcv_id,station_id,dbs_station_id,date_reading,create_date, 
                        // sum(after_filling_at_mgs_mfm_value_read-before_filing_at_mgs_mass_cng) as total_gas_mgs_mfm, 
                        // sum(after_filling_at_mgs_mass_cng-before_filing_at_mgs_mass_cng) as total_gas_mgs_calc, 
                        // sum(before_empty_at_db_mass_cng-after_empty_at_dbs_mass_cng) as total_gas_dbs_calc 
                        // from luag_transaction_master_dbs_station group by date_reading ORDER BY sl_no desc) t1 ,
                        // (SELECT `date_reading`,`cascade_mass`,`dbs_station_id`, sum(`diff_dispenser_reading`) as total_sale 
                        // FROM `luag_dispenser_reading` GROUP by date(`date_reading`),`dbs_station_id`) t2 
                        // where t1.dbs_station_id=t2.dbs_station_id and t1.date_reading=t2.date_reading");
                        // $stmt = $db->prepare("CALL `dispenser_reading`()");
                        // $stmt->execute();
                        $sql = "CALL dispenser_reading()";
                        $stmt = $db->query($sql);
                        $stmt->setFetchMode(PDO::FETCH_ASSOC);
                    } catch (PDOException $e) {
                        die("Error occurred:" . $e->getMessage());
                    }
                    while ($row = $stmt->fetch()) {
                    ?>
                        <tr>
                            <td bgcolor="#E9C006">
                                <?php echo $row["date_reading"]; ?>
                            </td>
                            <td bgcolor="#E9C006">
                                <?php echo $row["lcv_id"]; ?>
                            </td>
                           
                            <td bgcolor="#E9C006">
                                <?php echo $row["dbs_station_id"]; ?>
                            </td>
                            <td bgcolor="#E9C006">
                                <?php echo round($row["total_gas_dbs_calc"], 2); ?>
                            </td>
							<td bgcolor="#E9C006">
                            <?php echo $row["cascade_mass"]; ?>
							</td>

                            <td bgcolor="#E9C006">
                                <?php echo round($row["total_sale"], 2); ?>
                            </td>
                           

                        </tr>
                    <?php
                        $decimalHours = 0;
                    }
                    ?>
                </tbody>
            </table>
            <br><br>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="ddtf.js"></script>

    <script>
        $("#mytable2").ddTableFilter();
    </script>

    <script>
        $("#mytable3").ddTableFilter();
    </script>



</body>

</html>