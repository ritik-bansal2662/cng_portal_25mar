<?php


$connect = mysqli_connect("localhost", "root", "", "cng_luag");


/* Getting demo_viewer table data */
$sql = "select a.date_reading date,a.total_gas_dbs total_gas_received_at_mgs,
b.total_mass_of_gas,b.gas_sales, b.gas_sales*58.9 total_gas_sales,
a.total_gas_dbs-( b.gas_sales+b.total_mass_of_gas) total_loss_gas_dispenser , 
(a.total_gas_dbs-( b.gas_sales+b.total_mass_of_gas))/a.total_gas_dbs*100 percentage_loss_gas_dispenser 
from( select date_reading,sum(total_gas_dbs) total_gas_dbs 
from luag_transaction_master_dbs_station where total_gas_dbs <> '' group by date_reading) a ,
( select date_reading, sum(mass_of_gas) total_mass_of_gas,sum(dispenser_read) gas_sales 
from luag_transaction_dbs_dispenser_cascade group by date_reading)
 b where a.date_reading=b.date_reading group by b.date_reading";
$viewer = mysqli_query($connect, $sql);
$viewer = mysqli_fetch_all($viewer, MYSQLI_ASSOC);
$viewer = json_encode(array_column($viewer, 'percentage_loss_gas_dispenser'), JSON_NUMERIC_CHECK);


/* Getting demo_click table data */
$sql = "select a.date_reading date,a.total_gas_dbs total_gas_received_at_mgs,
b.total_mass_of_gas,b.gas_sales, b.gas_sales*58.9 total_gas_sales,
a.total_gas_dbs-( b.gas_sales+b.total_mass_of_gas) total_loss_gas_dispenser , 
(a.total_gas_dbs-( b.gas_sales+b.total_mass_of_gas))/a.total_gas_dbs*100 percentage_loss_gas_dispenser 
from( select date_reading,sum(total_gas_dbs) total_gas_dbs 
from luag_transaction_master_dbs_station where total_gas_dbs <> '' group by date_reading) a ,
( select date_reading, sum(mass_of_gas) total_mass_of_gas,sum(dispenser_read) gas_sales 
from luag_transaction_dbs_dispenser_cascade group by date_reading)
 b where a.date_reading=b.date_reading group by b.date_reading";
$click = mysqli_query($connect, $sql);
$click = mysqli_fetch_all($click, MYSQLI_ASSOC);
$click = json_encode(array_column($click, 'date '), JSON_NUMERIC_CHECK);


?>


<!DOCTYPE html>
<html>

<head>
    <title>HighChart</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
</head>

<body>


    <script type="text/javascript">
        $(function() {
            var data_click = <?php echo $click; ?>;
            var data_viewer = <?php echo $viewer; ?>;
            $('#container').highcharts({
                chart: {
                    type: 'line'
                },
                title: {
                    text: 'Yearly Website Ratio'
                },
                xAxis: {
                    name: 'Click',
                    categories: data_click
                },
                yAxis: {
                    title: {
                        text: 'Percentage'
                    }
                },
                series: [

                    {
                        name: 'Date',
                        data: data_viewer
                    }
                ]
            });
        });
    </script>


    <div class="container">
        <br />
        <h2 class="text-center">Highcharts php mysql json example</h2>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Dashboard</div>
                    <div class="panel-body">
                        <div id="container"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>